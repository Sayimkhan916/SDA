import java.util.ArrayList;
import java.util.List;

public class CloudAutoscaler {
    private List<CloudServer> servers = new ArrayList<>();

    public CloudAutoscaler() {

        servers.add(new CloudServer());
        servers.add(new CloudServer());
    }

    public void scaleUp() {
        servers.add(new CloudServer());
        System.out.println("Scaled up: Added a new server!");
    }

    public void distributeRequest(String request) {
        int serverIndex = Math.abs(request.hashCode() % servers.size());
        servers.get(serverIndex).handleRequest(request);
    }
}
