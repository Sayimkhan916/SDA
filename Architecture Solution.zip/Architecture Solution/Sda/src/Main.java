
public class Main {
    public static void main(String[] args) {
        CloudAutoscaler autoscaler = new CloudAutoscaler();

        autoscaler.distributeRequest("User1 Request");
        autoscaler.distributeRequest("User2 Request");

        autoscaler.scaleUp();

        autoscaler.distributeRequest("User3 Request");
        autoscaler.distributeRequest("User4 Request");
    }
}
