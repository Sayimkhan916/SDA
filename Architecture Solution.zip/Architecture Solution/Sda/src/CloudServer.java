
public class CloudServer {
    public void handleRequest(String request) {
        System.out.println("Handling request on cloud server: " + request);
    }
}
