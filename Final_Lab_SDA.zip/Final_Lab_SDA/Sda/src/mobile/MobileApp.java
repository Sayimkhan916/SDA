package mobile;

import server.Server;

public class MobileApp {
    private String userId;

    public MobileApp(String userId) {
        this.userId = userId;
    }

    public void sendDoorCommand(String command) {
        Server server = new Server("Server 1");
        server.receiveCommand(userId, command);
    }
}
