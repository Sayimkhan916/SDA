import mobile.MobileApp;

public class Main {
    public static void main(String[] args) {
        MobileApp mobileApp = new MobileApp("SAIM");

        mobileApp.sendDoorCommand("OPEN");
        mobileApp.sendDoorCommand("CLOSE");
        mobileApp.sendDoorCommand("INVALID");
    }
}
