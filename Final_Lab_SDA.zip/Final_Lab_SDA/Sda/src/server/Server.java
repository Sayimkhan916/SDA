package server;

import doors.ControllingDoors;

public class Server {
    private String serverId;
    private String doorStatus;

    public Server(String serverId) {
        this.serverId = serverId;
    }

    public void receiveCommand(String userId, String command) {
        System.out.println("Server: Received command from user " + userId + ": " + command);
        sendToDevice(command);
    }

    public void sendToDevice(String command) {
        ControllingDoors controllingDoors = new ControllingDoors("Door1");
        if ("OPEN".equalsIgnoreCase(command)) {
            controllingDoors.doorOpen();
        } else if ("CLOSE".equalsIgnoreCase(command)) {
            controllingDoors.doorClose();
        } else {
            System.out.println("Server: Invalid command!");
        }
        this.doorStatus = controllingDoors.getStatus();
        System.out.println("Server: Door status updated to: " + this.doorStatus);
    }
}
