package doors;

public class ControllingDoors {
    private String doorId;
    private String status;

    public ControllingDoors(String doorId) {
        this.doorId = doorId;
        this.status = "CLOSED";
    }

    public void doorOpen() {
        if (!"OPEN".equalsIgnoreCase(status)) {
            System.out.println("ControllingDoors: Opening the door...");
            status = "OPEN";
        } else {
            System.out.println("ControllingDoors: Door is already open.");
        }
    }

    public void doorClose() {
        if (!"CLOSED".equalsIgnoreCase(status)) {
            System.out.println("ControllingDoors: Closing the door...");
            status = "CLOSED";
        } else {
            System.out.println("ControllingDoors: Door is already closed.");
        }
    }

    public String getStatus() {
        return status;
    }
}
