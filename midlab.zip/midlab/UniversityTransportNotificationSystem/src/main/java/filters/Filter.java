package filters;

import java.util.List;

public interface Filter<I, O> {
    List<O> process(List<I> input);
}
