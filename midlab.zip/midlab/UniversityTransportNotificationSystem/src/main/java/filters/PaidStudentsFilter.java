package filters;

import models.Student;

import java.util.List;
import java.util.stream.Collectors;

public class PaidStudentsFilter implements Filter<Student, Student> {
    @Override
    public List<Student> process(List<Student> input) {
        return input.stream()
                .filter(Student::isHasPaid)
                .collect(Collectors.toList());
    }
}
