package filters;

import java.util.List;

public class PipelineExecutor<I, O> {
    private final List<Filter<?, ?>> filters;

    public PipelineExecutor(List<Filter<?, ?>> filters) {
        this.filters = filters;
    }

    @SuppressWarnings("unchecked")
    public <T> List<T> execute(List<I> input) {
        Object current = input;
        for (Filter<?, ?> filter : filters) {
            current = ((Filter<Object, Object>) filter).process((List<Object>) current);
        }
        return (List<T>) current;
    }
}
