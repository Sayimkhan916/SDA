package filters;

import models.Student;

import java.util.List;
import java.util.stream.Collectors;

public class NotificationTransformer implements Filter<Student, String> {
    @Override
    public List<String> process(List<Student> input) {
        return input.stream()
                .map(student -> "Dear " + student.getName() + ", your transport is scheduled.")
                .collect(Collectors.toList());
    }
}
