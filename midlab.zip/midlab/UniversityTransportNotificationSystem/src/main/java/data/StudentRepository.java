package data;

import models.Student;

import java.util.Arrays;
import java.util.List;

public class StudentRepository {
    public List<Student> fetchStudents() {
        return Arrays.asList(
                new Student("Ali", "S123", true),new Student("Ali khan", "S123", true),new Student("SAAd", "S123", true),
                new Student("Fatima", "S124", false),
                new Student("Hassan", "S125", true)
        );
    }
}
