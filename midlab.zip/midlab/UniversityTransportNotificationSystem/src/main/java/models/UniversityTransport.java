package models;

import java.util.ArrayList;
import java.util.List;

public class UniversityTransport {
    private String schedule;
    private boolean isPaidInAdvance;
    private List<Observer> observers = new ArrayList<>();

    public UniversityTransport(String schedule, boolean isPaidInAdvance) {
        this.schedule = schedule;
        this.isPaidInAdvance = isPaidInAdvance;
    }

    public void attach(Observer observer) {
        observers.add(observer);
    }

    public void detach(Observer observer) {
        observers.remove(observer);
    }

    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update("Bus schedule updated to: " + schedule);
        }
    }

    public void setSchedule(String newSchedule) {
        this.schedule = newSchedule;
        notifyObservers();
    }
}
