package models;

public class Student {
    private String name;
    private String studentId;
    private boolean hasPaid;

    public Student(String name, String studentId, boolean hasPaid) {
        this.name = name;
        this.studentId = studentId;
        this.hasPaid = hasPaid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public boolean isHasPaid() {
        return hasPaid;
    }

    public void setHasPaid(boolean hasPaid) {
        this.hasPaid = hasPaid;
    }

    public void receiveNotification(String message) {
        System.out.println("Notification to " + name + ": " + message);
    }
}
