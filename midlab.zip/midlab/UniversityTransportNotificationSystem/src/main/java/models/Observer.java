package models;

public interface Observer {
    void update(String message);
}
