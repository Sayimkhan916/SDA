package presentation;

import models.Student;
import services.UniversityTransportService;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Student> students = new ArrayList<>();
        students.add(new Student("Ali", "S123", true));
        students.add(new Student("Saad", "S456", true));
        students.add(new Student("SAud", "S789", false));

        UniversityTransportService transportService = new UniversityTransportService(students);

        transportService.notifyAtBusReadyTime();

        System.out.println("University Transport System is running...");
    }
}
