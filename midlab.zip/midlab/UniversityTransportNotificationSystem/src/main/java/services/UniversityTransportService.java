package services;

import models.Student;

import java.time.LocalTime;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class UniversityTransportService {
    private final List<Student> students;
    private final ScheduledExecutorService scheduler;

    public UniversityTransportService(List<Student> students) {
        this.students = students;
        this.scheduler = Executors.newScheduledThreadPool(1);
    }

    public void notifyAtBusReadyTime() {
        Runnable task = () -> {
            LocalTime now = LocalTime.now();
            if (now.getHour() == 8 && now.getMinute() == 0) {
                for (Student student : students) {
                    student.receiveNotification("The bus is ready to go, please take your seats.");
                }
            }
        };

        scheduler.scheduleAtFixedRate(task, 0, 1, TimeUnit.MINUTES);
    }

    public void stopScheduler() {
        scheduler.shutdown();
    }
}
